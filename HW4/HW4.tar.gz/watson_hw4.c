/*
* 	CSCI-5314 : HW4 : watson_hw4.c
*	Author: Mike Watson
*
*	Reads in a FASTA file and compares each pair of sequences to find either the global or local alignment.
*
*	This program uses a hash table to store the number of unique k-mers found in all the sequences.
*
*	Sample command line: ./hw4 -f example.fasta -g 2 -s nuc.score
*
*
*	In the event that the program is run with the -l option for local alignment, it will check each
*	Sequence pair to find the shortest sequence and run the alignment with that as the bottom sequence.
*	Trailing gaps are not penalized for the shorter sequence (bottom sequence).
*/

#define __USE_LARGEFILE64
#define _LARGEFILE_SOURCE
#define _LARGEFILE64_SOURCE


#include <stdio.h>
#include <getopt.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "watson_hw4.h"


int main (int argc, char** argv)
{
	char* fastaFile = NULL;
	char* scoringMatrixFile = NULL;
	int gapPenalty;
	char lookupTable[124] = {0};
	int numberOfSequences;
	
	Sequence* firstSequence = malloc(sizeof(Sequence));
	Sequence* currentSequence;
	
	/* -------Begin GETOPT parsing------- */
	
	int c;
	
	opterr = 0;
	
	while ((c = getopt (argc, argv, "f:g:s:")) != -1)
	{
		switch (c)
		{
			case 'f':
				/* handle fasta file argument */
				fastaFile = optarg;
				break;
			case 'g':
				/* handle global argument */
				gapPenalty = atoi(optarg);
			case 's':
				/* handle scoring matrix argument */
				scoringMatrixFile = optarg;
				break;
			case '?':
				if (optopt == 'f')
				{
					fastaFile = NULL;
				} else if (optopt == 's')
				{
					scoringMatrixFile = NULL;
				} else if (optopt == 'g')
				{
					gapPenalty = -19;
				} else
				{
					printf("Unknown option: %c\n", optopt);
				}
				return 1;
			default:
				abort ();
		}
	}
	
	/* -------End GETOPT parsing------- */
	
	if (fastaFile == NULL)
	{
		printf("Please specify a FASTA file for input. (use %s -f FILENAME to specify)\n", argv[0]);
		
		exit(1);
	}
	
	if (scoringMatrixFile == NULL)
	{
		printf("Please specify a Scoring Matrix file. (use %s -s FILENAME to specify)\n", argv[0]);
		
		exit(1);
	}
	
	if (gapPenalty < 0)
	{
		printf("Please specify a positive integer gap penalty. (use %s -g NUM to specify)\n", argv[0]);
	
		exit(1);
	}

	ScoringMatrix* score = read_scoring_file(scoringMatrixFile);
	
	// Only testing the read_scoring_file function
	exit(0);

	char* fileBuffer = read_file(fastaFile, firstSequence, score, &numberOfSequences);
	
	if (fileBuffer == NULL)
	{
		/* error reading from file */
		printf ("Unable to read from file: %s. Exiting...", fastaFile);
		exit(0);
	}
	
	currentSequence = firstSequence;
	AlignmentMatrix* aligned;
	
	while (currentSequence != NULL)
	{
		for (int i = 0; i < currentSequence->sequenceLength; i++)
		{
			printf ("%d", currentSequence->data[i]);
		}
		printf("\n");
		currentSequence = currentSequence->next;
	}
	
	Node* root = build_tree(score, firstSequence, gapPenalty, numberOfSequences);
	
	
	free(fileBuffer);
	
	return 0;
}

ScoringMatrix* read_scoring_file(char* scoreFile)
{
	ScoringMatrix* scoring = malloc(sizeof(ScoringMatrix));
	scoring->numChars = 0;
	
	char line[256];
	char* temp;
	int lineLength;
	int numLines = 0;
	int i;
	int j;
	
	FILE* file = fopen(scoreFile, "r");
	
	if (fgets(line, 256, file) != NULL)
	{
		strtok(line, " \t\n");
		
		while (strtok(NULL, " \t\n") != NULL)
		{
			scoring->numChars++;
		}
	} else
	{
		printf("Unable to read from score file. Exiting.\n");
		exit(1);
	}
	
	rewind(file);
	
	scoring->matrix = malloc(sizeof(char) * (scoring->numChars) * (scoring->numChars));
	scoring->lookupTable = calloc(128, sizeof(char));
	
	
	
	//memset(scoring->lookupTable, -1, sizeof(char) * 128);
	char look[128] = {-1};
	memset(look, -1, sizeof(char) * 128);
	
		for (int i = 0; i < 128; i++)
	{
		scoring->lookupTable[i] = look[i];
	}
	
	for (int i = 0; i < 128; i++)
	{
		printf("%d ", look[i]);
	}
	
	printf("\n");
	scoring->lookupTableReverse = malloc (sizeof(char) * (scoring->numChars));
	
	for (i = 0; i < scoring->numChars; i++)
	{
		fgets(line, 256, file);

		temp = strtok(line, " \t\n");

		j = 0;
		
		printf("Adding char %c to lookupTable as %d\n", temp[0], i);
		
		scoring->lookupTable[temp[0]] = i;
		scoring->lookupTable[temp[0] ^ 32 ] = i;

		// stack variable works fine.
		look[temp[0]] = i;
		look[temp[0] ^ 32] = i;
		
		scoring->lookupTableReverse[i] = temp[0];
		
		for (int i = 0; i < 128; i++)
		{
			printf("%d ",scoring->lookupTable[i]);
		}
		printf("\n");
		
		while (((temp = strtok(NULL, " \t\n")) != NULL) && j <= scoring->numChars)
		{
			scoring->matrix[ i * (scoring->numChars) + j++] = atoi(temp);
			//printf("Adding int %d\n", atoi(temp));
		}
	}
	
	// for (i = 0; i < scoring->numChars; i++)
	// {
	// 	printf("%c\t", scoring->lookupTableReverse[i]);
	// 	for (j = 0; j < scoring->numChars; j++)
	// 	{
	// 		printf("%d\t", scoring->matrix[i * (scoring->numChars) + j]);
	// 	}
	// 	printf("\n");
	// }
	
	// for (int i = 0; i < 126; i++)
	// {
	// 	printf("%d ", scoring->lookupTable[i]);
	// }


	printf("test\n");
	fflush(stdout);
	
	// segfault on file close.
	fclose(file);

	return scoring;
}


Node* build_tree(ScoringMatrix* score, Sequence* currentSequence, int gapPenalty, int numberOfSequences)
{
	Sequence* otherSequence;
	Node* newNode;
	
	int i = 0;
	int j;
	
	float distanceMatrix[numberOfSequences][numberOfSequences];;
	Node* sequenceNodeArray[numberOfSequences];
	
	while (currentSequence != NULL)
	{
		j = i + 1;
		
		sequenceNodeArray[i] = malloc(sizeof(Node));
		sequenceNodeArray[i]->sequence = currentSequence;
		sequenceNodeArray[i]->height = 0;
		
		otherSequence = currentSequence->next;
		
		while (otherSequence != NULL)
		{
			distanceMatrix[i][i] = 0;
			distanceMatrix[i][j] = distanceMatrix[j][i] = global_alignment_distance(currentSequence, otherSequence, score, gapPenalty);
			
			//printf("Sequence %d - %d: %.2f\n", i, j, distanceMatrix[i][j]);
			j++;
			otherSequence = otherSequence->next;
		}
		
		++i;
		currentSequence = currentSequence->next;
	}
	
	printf(" \t");
	for (int a = 0; a < numberOfSequences; a++)
	{
		printf("%c\t", 'a' + a);
	}
	printf("\n");
	
	for (int a = 0; a < numberOfSequences; a++)
	{
		printf("%c\t", 'a' + a);
		for (int b = 0; b < numberOfSequences; b++)
		{
			printf ("%.2f\t", distanceMatrix[a][b]);
		}
		printf("\n");
	}
	
	int minDistance;
	int min1;
	int min2;
	
	while (numberOfSequences > 0)
	{
		for (i = 0; i < numberOfSequences; i++)
		{
			for (j = i + 1; j < numberOfSequences; j++)
			{
				if (distanceMatrix[i][j] < minDistance)
				{
					minDistance = distanceMatrix[i][j];
					min1 = i;
					min2 = j;
				}
			}
		}
		
		sequenceNodeArray[min1]->distance = (minDistance / (float) 2) - sequenceNodeArray[min1]->height;
		sequenceNodeArray[min2]->distance = (minDistance / (float) 2) - sequenceNodeArray[min2]->height;
		
		newNode = malloc(sizeof(Node));
		newNode->left = sequenceNodeArray[min1];
		newNode->right = sequenceNodeArray[min2];
		newNode->height = newNode->left->distance + newNode->left->height;
		
		sequenceNodeArray[min1] = newNode;
		
		while (min2 < numberOfSequences)
		{
			sequenceNodeArray[min2] = sequenceNodeArray [++min2];
		}
		
		
		
	}
	
	
}


/*
*	Reads a file into memory and builds a linked-list containing all the sequences found in the file.
*	Uses stat64() and fopen64() to allow for loading files larger than 2GB.
*
*	All file data is stored in the fileBuffer array and each of the sequence structs use pointers to
*	access their respective data.
*
*	ARGS
*		char* inputFile - String containing the file location.
*		Sequence* currentSequence - pointer to the memory location of the first member of a linked list
*									that will contain all the sequences read in from the file.
*
*	RETURN: char* - returns a pointer to an array containing all data read in from the file. The sequence
					linked list contains pointers to their respective information.
*/
char* read_file(char* inputFile, Sequence* currentSequence, ScoringMatrix* score, int* numberOfSequences)
{
	char* fileBuffer;
	int fileSize;
	int c;
	int read;
	int sequenceStart;
	int index = 0;
	*numberOfSequences = 0;
	
	struct stat64 statStruct;
	
	// check the file size in order to malloc the necessary amount of memory to the fileBuffer array.
	if (stat64(inputFile, &statStruct) == -1)
	{
		return NULL;
	}
	
	fileSize = statStruct.st_size;
	
	FILE* file = fopen64(inputFile, "r");

	fileBuffer = malloc(fileSize);
	
	while ((c = fgetc(file)) != '\n')
	{
		if (c == '>')
		{
			*numberOfSequences += 1;
			currentSequence->sequenceName = &fileBuffer[index];
		} else if (c == ' ')
		{
			fileBuffer[index++] = '\0';
			currentSequence->sequenceDescription = &fileBuffer[index];
		} else
		{
			fileBuffer[index++] = c;
		}
	}
	
	fileBuffer[index++] = '\0';
	currentSequence->sequenceType = 1;
	currentSequence->data = &fileBuffer[index];
	sequenceStart = index;
	
	// Uses fgetc to read the file in one byte at a time.
	// Any ASCII character of lesser numerical value than 'A' will be checked if it is '>' to signify
	// a new sequence start.
	// Any other non-alphabet characters will be ignored in order to skip newlines in the sequence data.
	while((c = fgetc(file)) != EOF)
	{
		printf("CHAR: %c = %d ", c, score->lookupTable[c]);
		if (score->lookupTable[c] < 0)
		{
			if (c == '>')
			{
				printf("\n");
				*numberOfSequences += 1;
				currentSequence->sequenceLength = index - sequenceStart;
				currentSequence->next = malloc(sizeof(Sequence));
				currentSequence = currentSequence->next;
				currentSequence->sequenceName = &fileBuffer[index];
				currentSequence->sequenceType = 1;
				while ( (c = fgetc(file)) != '\n')
				{
					if (c == ' ')
					{
						fileBuffer[index++] = '\0';
						currentSequence->sequenceDescription = &fileBuffer[index];
					} else
					{
						fileBuffer[index++] = (char) c;
					}
				}
				
				fileBuffer[index++] = '\0';
				currentSequence->data = &fileBuffer[index];
				sequenceStart = index;
			} else if (c == '\n')
			{
			}else
			{
				printf("Error: character '%c' is not defined in the scoring matrix file. Exiting.\n", c);
				exit(1);
			}
		} else
		{
			fileBuffer[index++] = score->lookupTable[c];
		}
	}
	
	currentSequence->sequenceLength = index - sequenceStart;

	return fileBuffer;
}


/*
*	Calculates the global alignment using the Needleman-Wunsch algorithm
*
*	ARGS:
*		Sequence* sequenceOne - horizonatal sequence used for alignemnt
*		Sequence* sequenceTwo - verticle sequence used for alignment
*
*	RETURN:  AlignmentMatrix* - Returns an AlignmentMatrix struct containing the 2d dynamic programming
*					matrices for score and direction.
*/
float global_alignment_distance(Sequence* sequenceOne, Sequence* sequenceTwo, ScoringMatrix* score, int gapPenalty)
{
	AlignmentMatrix* alignment = malloc(sizeof(AlignmentMatrix));
	
	alignment->matrixWidth = sequenceOne->sequenceLength + 1;
	alignment->matrixHeight = sequenceTwo->sequenceLength + 1;
	int bestScore = 0;
	
	int directionTable[3] = { 1, alignment->matrixWidth + 1, alignment->matrixWidth };
	
	alignment->score = malloc(alignment->matrixWidth * alignment->matrixHeight * sizeof(int));
	//alignment->direction = malloc(alignment->matrixWidth * alignment->matrixHeight * sizeof(char));
	
	int i;
	int j;
	int index;
	int left;
	int diag;
	int up;
	
	
	alignment->score[0] = 0;
	
	for (j = 1; j < alignment->matrixWidth; j++)
	{
		alignment->score[j] = j * GLOBAL_GAP;
		bestScore += score->matrix[sequenceOne->data[j-1] * (score->numChars) + sequenceOne->data[j-1]];
	}
	
	for (i = 1; i < alignment->matrixHeight; i++)
	{
		alignment->score[i * alignment->matrixWidth] = i * -gapPenalty;
		for (j = 1; j < alignment->matrixWidth; j++)
		{
			index = i * alignment->matrixWidth + j;
			left = alignment->score[index - directionTable[LEFT]] - gapPenalty;
			diag = alignment->score[index - directionTable[DIAG]]
								+ score->matrix[sequenceOne->data[i-1] * (score->numChars) + sequenceTwo->data[j-1]];
			//printf("%c - %c: %d\n", score->lookupTableReverse[sequenceOne->data[i-1]],score->lookupTableReverse[sequenceTwo->data[j-1]], score->matrix[sequenceOne->data[i-1] * (score->numChars) + sequenceTwo->data[j-1]] );
								
			//(sequenceOne->data[j - 1] == sequenceTwo->data[i - 1] ? GLOBAL_MATCH : GLOBAL_MISMATCH);
			up = alignment->score[index - directionTable[UP]] - gapPenalty;
			
			if ( left > diag )
			{
				if ( left > up )
				{
					alignment->score[index] = left;
				}
				else
				{
					alignment->score[index] = up;
				}
			}
			else
			{
				if ( up > diag )
				{
					alignment->score[index] = up;
				}
				else
				{
					alignment->score[index] = diag;
				}
			}
		}
	}
	
	
	float returnVal = ((bestScore - (float)alignment->score[index]) * 50)/bestScore;
	//printf("BestValue: %d\n", bestScore);
	
	//printf("test: %.1f\n", ((bestScore - returnVal) * 50)/bestScore);

	free(alignment->score);
	free(alignment);
	
	return returnVal ;
}


void print_tree(Node* aNode)
{
	if (aNode->sequence != NULL)
	{
		printf("%s:%d", aNode->sequence->sequenceName, aNode->distance);
	} else
	{
		printf("(");
		print_tree(aNode->left);
		printf(",");
		print_tree(aNode->right);
		printf("):%d", aNode->distance);
	}
}